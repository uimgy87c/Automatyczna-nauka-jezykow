# Automatyczna nauka języków
 Program pod Windows umożliwiający wygodną i szybką naukę języków.
<br/>
- Polecam korzystać z głosami syntezatora mowy IVONA (IVONA Salli dla j. angielskiego i IVONA Maja dla j. polskiego).
- Wiem, że UI jest kiepskie (zamierzam poprawić w przyszłości).
