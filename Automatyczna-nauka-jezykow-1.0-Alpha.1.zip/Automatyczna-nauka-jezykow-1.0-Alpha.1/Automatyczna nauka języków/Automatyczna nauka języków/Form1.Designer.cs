﻿namespace Automatyczna_nauka_języków
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LBwordbases = new System.Windows.Forms.ListBox();
            this.CMS_LBwordbases = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIedit_wordbase = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIdelete_wordbase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TSMIplik = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIload_wordbases = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIcontrol_keys = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIhelp = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CHBread_sentence_f = new System.Windows.Forms.CheckBox();
            this.CHBread_sentence_n = new System.Windows.Forms.CheckBox();
            this.CHBread_word_f = new System.Windows.Forms.CheckBox();
            this.CHBread_word_n = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LBwords = new System.Windows.Forms.ListBox();
            this.CMS_LBwords = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TSMIedit_word = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIset_word_as_current = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIdelete_word = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.CHBshow_words = new System.Windows.Forms.CheckBox();
            this.RBn_f = new System.Windows.Forms.RadioButton();
            this.RBf_n = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CHBshow_sentences = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TBbetween_delay = new System.Windows.Forms.TextBox();
            this.TBsentence_delay = new System.Windows.Forms.TextBox();
            this.TBword_delay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TBrepeats = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.RBturbo = new System.Windows.Forms.RadioButton();
            this.RBsemi_auto = new System.Windows.Forms.RadioButton();
            this.RBhybrid = new System.Windows.Forms.RadioButton();
            this.RBchecking = new System.Windows.Forms.RadioButton();
            this.RBpresentation = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Breset_current_word_nr = new System.Windows.Forms.Button();
            this.TBremaining_time = new System.Windows.Forms.TextBox();
            this.TBwords_nr = new System.Windows.Forms.TextBox();
            this.TBcurrent_word_nr = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.TBlast_wordbase_name = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Bstart_learning = new System.Windows.Forms.Button();
            this.Brestore_default = new System.Windows.Forms.Button();
            this.OFD1 = new System.Windows.Forms.OpenFileDialog();
            this.Badd_word = new System.Windows.Forms.Button();
            this.Badd_wordbase = new System.Windows.Forms.Button();
            this.PB_move_up = new System.Windows.Forms.PictureBox();
            this.PB_move_down = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.CBvoice_f = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.CBvolume = new System.Windows.Forms.ComboBox();
            this.CBvoice_n = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.RBvariable_color = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.RBconstant_color = new System.Windows.Forms.RadioButton();
            this.TBback_color = new System.Windows.Forms.TextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.CMS_LBwordbases.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.CMS_LBwords.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_move_up)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_move_down)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBwordbases
            // 
            this.LBwordbases.ContextMenuStrip = this.CMS_LBwordbases;
            this.LBwordbases.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LBwordbases.FormattingEnabled = true;
            this.LBwordbases.ItemHeight = 18;
            this.LBwordbases.Location = new System.Drawing.Point(36, 60);
            this.LBwordbases.Margin = new System.Windows.Forms.Padding(4);
            this.LBwordbases.Name = "LBwordbases";
            this.LBwordbases.Size = new System.Drawing.Size(290, 562);
            this.LBwordbases.TabIndex = 1;
            this.LBwordbases.Click += new System.EventHandler(this.LBwordbases_Click);
            this.LBwordbases.DoubleClick += new System.EventHandler(this.LBwordbases_DoubleClick);
            this.LBwordbases.KeyUp += new System.Windows.Forms.KeyEventHandler(this.LBwordbases_KeyUp);
            // 
            // CMS_LBwordbases
            // 
            this.CMS_LBwordbases.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIedit_wordbase,
            this.TSMIdelete_wordbase});
            this.CMS_LBwordbases.Name = "CMS_LBwordbases";
            this.CMS_LBwordbases.Size = new System.Drawing.Size(174, 48);
            // 
            // TSMIedit_wordbase
            // 
            this.TSMIedit_wordbase.Name = "TSMIedit_wordbase";
            this.TSMIedit_wordbase.Size = new System.Drawing.Size(173, 22);
            this.TSMIedit_wordbase.Text = "Edytuj bazę słówek";
            this.TSMIedit_wordbase.Click += new System.EventHandler(this.TSMIedit_wordbase_Click);
            // 
            // TSMIdelete_wordbase
            // 
            this.TSMIdelete_wordbase.Name = "TSMIdelete_wordbase";
            this.TSMIdelete_wordbase.Size = new System.Drawing.Size(173, 22);
            this.TSMIdelete_wordbase.Text = "Usuń bazę słówek";
            this.TSMIdelete_wordbase.Click += new System.EventHandler(this.TSMIdelete_wordbase_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Font = new System.Drawing.Font("Calibri", 10F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIplik,
            this.TSMIcontrol_keys,
            this.TSMIhelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1187, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // TSMIplik
            // 
            this.TSMIplik.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIload_wordbases});
            this.TSMIplik.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TSMIplik.Name = "TSMIplik";
            this.TSMIplik.Size = new System.Drawing.Size(39, 21);
            this.TSMIplik.Text = "Plik";
            // 
            // TSMIload_wordbases
            // 
            this.TSMIload_wordbases.Name = "TSMIload_wordbases";
            this.TSMIload_wordbases.Size = new System.Drawing.Size(149, 22);
            this.TSMIload_wordbases.Text = "Wczytaj bazy";
            this.TSMIload_wordbases.Click += new System.EventHandler(this.TSMIload_wordbases_Click);
            // 
            // TSMIcontrol_keys
            // 
            this.TSMIcontrol_keys.Name = "TSMIcontrol_keys";
            this.TSMIcontrol_keys.Size = new System.Drawing.Size(95, 21);
            this.TSMIcontrol_keys.Text = "Klawiszologia";
            this.TSMIcontrol_keys.Click += new System.EventHandler(this.TSMIcontrol_keys_Click);
            // 
            // TSMIhelp
            // 
            this.TSMIhelp.Name = "TSMIhelp";
            this.TSMIhelp.Size = new System.Drawing.Size(58, 21);
            this.TSMIhelp.Text = "Pomoc";
            this.TSMIhelp.Click += new System.EventHandler(this.TSMIhelp_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CHBread_sentence_f);
            this.groupBox1.Controls.Add(this.CHBread_sentence_n);
            this.groupBox1.Controls.Add(this.CHBread_word_f);
            this.groupBox1.Controls.Add(this.CHBread_word_n);
            this.groupBox1.Location = new System.Drawing.Point(631, 146);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 132);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Syntezator mowy";
            // 
            // CHBread_sentence_f
            // 
            this.CHBread_sentence_f.AutoSize = true;
            this.CHBread_sentence_f.Location = new System.Drawing.Point(6, 104);
            this.CHBread_sentence_f.Name = "CHBread_sentence_f";
            this.CHBread_sentence_f.Size = new System.Drawing.Size(164, 21);
            this.CHBread_sentence_f.TabIndex = 3;
            this.CHBread_sentence_f.Text = "Czytaj zdanie w j. obcym";
            this.CHBread_sentence_f.UseVisualStyleBackColor = true;
            this.CHBread_sentence_f.CheckedChanged += new System.EventHandler(this.CHBread_sentence_f_CheckedChanged);
            // 
            // CHBread_sentence_n
            // 
            this.CHBread_sentence_n.AutoSize = true;
            this.CHBread_sentence_n.Location = new System.Drawing.Point(6, 77);
            this.CHBread_sentence_n.Name = "CHBread_sentence_n";
            this.CHBread_sentence_n.Size = new System.Drawing.Size(169, 21);
            this.CHBread_sentence_n.TabIndex = 2;
            this.CHBread_sentence_n.Text = "Czytaj zdanie w j. polskim";
            this.CHBread_sentence_n.UseVisualStyleBackColor = true;
            this.CHBread_sentence_n.CheckedChanged += new System.EventHandler(this.CHBread_sentence_n_CheckedChanged);
            // 
            // CHBread_word_f
            // 
            this.CHBread_word_f.AutoSize = true;
            this.CHBread_word_f.Location = new System.Drawing.Point(6, 50);
            this.CHBread_word_f.Name = "CHBread_word_f";
            this.CHBread_word_f.Size = new System.Drawing.Size(165, 21);
            this.CHBread_word_f.TabIndex = 1;
            this.CHBread_word_f.Text = "Czytaj słówko w j. obcym";
            this.CHBread_word_f.UseVisualStyleBackColor = true;
            this.CHBread_word_f.CheckedChanged += new System.EventHandler(this.CHBread_word_f_CheckedChanged);
            // 
            // CHBread_word_n
            // 
            this.CHBread_word_n.AutoSize = true;
            this.CHBread_word_n.Location = new System.Drawing.Point(6, 23);
            this.CHBread_word_n.Name = "CHBread_word_n";
            this.CHBread_word_n.Size = new System.Drawing.Size(170, 21);
            this.CHBread_word_n.TabIndex = 0;
            this.CHBread_word_n.Text = "Czytaj słówko w j. polskim";
            this.CHBread_word_n.UseVisualStyleBackColor = true;
            this.CHBread_word_n.CheckedChanged += new System.EventHandler(this.CHBread_word_n_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(32, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Bazy słówek";
            // 
            // LBwords
            // 
            this.LBwords.ContextMenuStrip = this.CMS_LBwords;
            this.LBwords.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LBwords.FormattingEnabled = true;
            this.LBwords.ItemHeight = 18;
            this.LBwords.Location = new System.Drawing.Point(334, 60);
            this.LBwords.Margin = new System.Windows.Forms.Padding(4);
            this.LBwords.Name = "LBwords";
            this.LBwords.Size = new System.Drawing.Size(290, 562);
            this.LBwords.TabIndex = 6;
            this.LBwords.DoubleClick += new System.EventHandler(this.LBwords_DoubleClick);
            this.LBwords.KeyUp += new System.Windows.Forms.KeyEventHandler(this.LBwords_KeyUp);
            // 
            // CMS_LBwords
            // 
            this.CMS_LBwords.Font = new System.Drawing.Font("Calibri", 10F);
            this.CMS_LBwords.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIedit_word,
            this.TSMIset_word_as_current,
            this.TSMIdelete_word});
            this.CMS_LBwords.Name = "CMS_LBwords";
            this.CMS_LBwords.Size = new System.Drawing.Size(226, 70);
            // 
            // TSMIedit_word
            // 
            this.TSMIedit_word.Name = "TSMIedit_word";
            this.TSMIedit_word.Size = new System.Drawing.Size(225, 22);
            this.TSMIedit_word.Text = "Edytuj słówko";
            this.TSMIedit_word.Click += new System.EventHandler(this.TSMIedit_word_Click);
            // 
            // TSMIset_word_as_current
            // 
            this.TSMIset_word_as_current.Name = "TSMIset_word_as_current";
            this.TSMIset_word_as_current.Size = new System.Drawing.Size(225, 22);
            this.TSMIset_word_as_current.Text = "Ustaw słówko jako bieżące";
            this.TSMIset_word_as_current.Click += new System.EventHandler(this.TSMIset_word_as_current_Click);
            // 
            // TSMIdelete_word
            // 
            this.TSMIdelete_word.Name = "TSMIdelete_word";
            this.TSMIdelete_word.Size = new System.Drawing.Size(225, 22);
            this.TSMIdelete_word.Text = "Usuń słówko";
            this.TSMIdelete_word.Click += new System.EventHandler(this.TSMIdelete_word_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(330, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "Lista słówek bazy";
            // 
            // CHBshow_words
            // 
            this.CHBshow_words.AutoSize = true;
            this.CHBshow_words.Location = new System.Drawing.Point(6, 23);
            this.CHBshow_words.Name = "CHBshow_words";
            this.CHBshow_words.Size = new System.Drawing.Size(111, 21);
            this.CHBshow_words.TabIndex = 9;
            this.CHBshow_words.Text = "Pokazuj słówka";
            this.CHBshow_words.UseVisualStyleBackColor = true;
            this.CHBshow_words.CheckedChanged += new System.EventHandler(this.CHBshow_words_CheckedChanged);
            // 
            // RBn_f
            // 
            this.RBn_f.AutoSize = true;
            this.RBn_f.Location = new System.Drawing.Point(9, 23);
            this.RBn_f.Name = "RBn_f";
            this.RBn_f.Size = new System.Drawing.Size(117, 21);
            this.RBn_f.TabIndex = 10;
            this.RBn_f.TabStop = true;
            this.RBn_f.Text = "J. Polski - J. Obcy";
            this.RBn_f.UseVisualStyleBackColor = true;
            this.RBn_f.CheckedChanged += new System.EventHandler(this.RBn_f_CheckedChanged);
            // 
            // RBf_n
            // 
            this.RBf_n.AutoSize = true;
            this.RBf_n.Location = new System.Drawing.Point(9, 50);
            this.RBf_n.Name = "RBf_n";
            this.RBf_n.Size = new System.Drawing.Size(117, 21);
            this.RBf_n.TabIndex = 11;
            this.RBf_n.TabStop = true;
            this.RBf_n.Text = "J. Obcy - J. Polski";
            this.RBf_n.UseVisualStyleBackColor = true;
            this.RBf_n.CheckedChanged += new System.EventHandler(this.RBf_n_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CHBshow_sentences);
            this.groupBox2.Controls.Add(this.CHBshow_words);
            this.groupBox2.Location = new System.Drawing.Point(631, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(300, 80);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pokazywanie";
            // 
            // CHBshow_sentences
            // 
            this.CHBshow_sentences.AutoSize = true;
            this.CHBshow_sentences.Location = new System.Drawing.Point(6, 50);
            this.CHBshow_sentences.Name = "CHBshow_sentences";
            this.CHBshow_sentences.Size = new System.Drawing.Size(110, 21);
            this.CHBshow_sentences.TabIndex = 10;
            this.CHBshow_sentences.Text = "Pokazuj zdania";
            this.CHBshow_sentences.UseVisualStyleBackColor = true;
            this.CHBshow_sentences.CheckedChanged += new System.EventHandler(this.CHBshow_sentences_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(627, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 23);
            this.label3.TabIndex = 13;
            this.label3.Text = "Ustawienia";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.TBbetween_delay);
            this.groupBox3.Controls.Add(this.TBsentence_delay);
            this.groupBox3.Controls.Add(this.TBword_delay);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox3.Location = new System.Drawing.Point(631, 284);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(364, 115);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Opóźnienia";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(320, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "sek";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(320, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "sek";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(320, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "sek";
            // 
            // TBbetween_delay
            // 
            this.TBbetween_delay.Location = new System.Drawing.Point(285, 79);
            this.TBbetween_delay.MaxLength = 3;
            this.TBbetween_delay.Name = "TBbetween_delay";
            this.TBbetween_delay.Size = new System.Drawing.Size(29, 24);
            this.TBbetween_delay.TabIndex = 5;
            this.TBbetween_delay.TextChanged += new System.EventHandler(this.TBbetween_delay_TextChanged);
            // 
            // TBsentence_delay
            // 
            this.TBsentence_delay.Location = new System.Drawing.Point(285, 53);
            this.TBsentence_delay.MaxLength = 3;
            this.TBsentence_delay.Name = "TBsentence_delay";
            this.TBsentence_delay.Size = new System.Drawing.Size(29, 24);
            this.TBsentence_delay.TabIndex = 4;
            this.TBsentence_delay.TextChanged += new System.EventHandler(this.TBsentence_delay_TextChanged);
            // 
            // TBword_delay
            // 
            this.TBword_delay.Location = new System.Drawing.Point(285, 27);
            this.TBword_delay.MaxLength = 3;
            this.TBword_delay.Name = "TBword_delay";
            this.TBword_delay.Size = new System.Drawing.Size(29, 24);
            this.TBword_delay.TabIndex = 3;
            this.TBword_delay.TextChanged += new System.EventHandler(this.TBword_delay_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(265, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Opóźnienie pomiędzy nauką kolejnych słówek:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(280, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Dodatkowe opóźnienie po pojawieniu się zdania:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(281, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Dodatkowe opóźnienie po pojawieniu się słówka:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TBrepeats);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.RBn_f);
            this.groupBox4.Controls.Add(this.RBf_n);
            this.groupBox4.Location = new System.Drawing.Point(939, 173);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(244, 105);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Metoda nauki";
            // 
            // TBrepeats
            // 
            this.TBrepeats.Location = new System.Drawing.Point(205, 73);
            this.TBrepeats.MaxLength = 2;
            this.TBrepeats.Name = "TBrepeats";
            this.TBrepeats.Size = new System.Drawing.Size(29, 24);
            this.TBrepeats.TabIndex = 9;
            this.TBrepeats.TextChanged += new System.EventHandler(this.TBrepeats_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(202, 17);
            this.label10.TabIndex = 12;
            this.label10.Text = "Liczba powtórzeń każdego słówka:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.RBturbo);
            this.groupBox5.Controls.Add(this.RBsemi_auto);
            this.groupBox5.Controls.Add(this.RBhybrid);
            this.groupBox5.Controls.Add(this.RBchecking);
            this.groupBox5.Controls.Add(this.RBpresentation);
            this.groupBox5.Location = new System.Drawing.Point(1003, 284);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(180, 130);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tryb nauki";
            // 
            // RBturbo
            // 
            this.RBturbo.AutoSize = true;
            this.RBturbo.Location = new System.Drawing.Point(99, 78);
            this.RBturbo.Name = "RBturbo";
            this.RBturbo.Size = new System.Drawing.Size(58, 21);
            this.RBturbo.TabIndex = 17;
            this.RBturbo.TabStop = true;
            this.RBturbo.Text = "Turbo";
            this.RBturbo.UseVisualStyleBackColor = true;
            this.RBturbo.CheckedChanged += new System.EventHandler(this.RBturbo_CheckedChanged);
            // 
            // RBsemi_auto
            // 
            this.RBsemi_auto.AutoSize = true;
            this.RBsemi_auto.Location = new System.Drawing.Point(9, 104);
            this.RBsemi_auto.Name = "RBsemi_auto";
            this.RBsemi_auto.Size = new System.Drawing.Size(123, 21);
            this.RBsemi_auto.TabIndex = 16;
            this.RBsemi_auto.TabStop = true;
            this.RBsemi_auto.Text = "Półautomatyczny";
            this.RBsemi_auto.UseVisualStyleBackColor = true;
            this.RBsemi_auto.CheckedChanged += new System.EventHandler(this.RBsemi_auto_CheckedChanged);
            // 
            // RBhybrid
            // 
            this.RBhybrid.AutoSize = true;
            this.RBhybrid.Location = new System.Drawing.Point(9, 77);
            this.RBhybrid.Name = "RBhybrid";
            this.RBhybrid.Size = new System.Drawing.Size(89, 21);
            this.RBhybrid.TabIndex = 15;
            this.RBhybrid.TabStop = true;
            this.RBhybrid.Text = "Hybrydowy";
            this.RBhybrid.UseVisualStyleBackColor = true;
            this.RBhybrid.CheckedChanged += new System.EventHandler(this.RBhybrid_CheckedChanged);
            // 
            // RBchecking
            // 
            this.RBchecking.AutoSize = true;
            this.RBchecking.Location = new System.Drawing.Point(9, 50);
            this.RBchecking.Name = "RBchecking";
            this.RBchecking.Size = new System.Drawing.Size(140, 21);
            this.RBchecking.TabIndex = 14;
            this.RBchecking.TabStop = true;
            this.RBchecking.Text = "Sprawdzanie wiedzy";
            this.RBchecking.UseVisualStyleBackColor = true;
            this.RBchecking.CheckedChanged += new System.EventHandler(this.RBchecking_CheckedChanged);
            // 
            // RBpresentation
            // 
            this.RBpresentation.AutoSize = true;
            this.RBpresentation.Location = new System.Drawing.Point(9, 23);
            this.RBpresentation.Name = "RBpresentation";
            this.RBpresentation.Size = new System.Drawing.Size(154, 21);
            this.RBpresentation.TabIndex = 13;
            this.RBpresentation.TabStop = true;
            this.RBpresentation.Text = "Przedstawianie wiedzy";
            this.RBpresentation.UseVisualStyleBackColor = true;
            this.RBpresentation.CheckedChanged += new System.EventHandler(this.RBpresentation_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Breset_current_word_nr);
            this.groupBox6.Controls.Add(this.TBremaining_time);
            this.groupBox6.Controls.Add(this.TBwords_nr);
            this.groupBox6.Controls.Add(this.TBcurrent_word_nr);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Location = new System.Drawing.Point(631, 415);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(371, 108);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Informacje o bazie słówek";
            // 
            // Breset_current_word_nr
            // 
            this.Breset_current_word_nr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Breset_current_word_nr.Location = new System.Drawing.Point(240, 26);
            this.Breset_current_word_nr.Name = "Breset_current_word_nr";
            this.Breset_current_word_nr.Size = new System.Drawing.Size(124, 77);
            this.Breset_current_word_nr.TabIndex = 8;
            this.Breset_current_word_nr.Text = "Zresetuj nr. bieżącego słówka";
            this.Breset_current_word_nr.UseVisualStyleBackColor = true;
            this.Breset_current_word_nr.Click += new System.EventHandler(this.Breset_current_word_nr_Click);
            // 
            // TBremaining_time
            // 
            this.TBremaining_time.Location = new System.Drawing.Point(142, 79);
            this.TBremaining_time.MaxLength = 10;
            this.TBremaining_time.Name = "TBremaining_time";
            this.TBremaining_time.ReadOnly = true;
            this.TBremaining_time.Size = new System.Drawing.Size(92, 24);
            this.TBremaining_time.TabIndex = 6;
            // 
            // TBwords_nr
            // 
            this.TBwords_nr.Location = new System.Drawing.Point(142, 52);
            this.TBwords_nr.MaxLength = 10;
            this.TBwords_nr.Name = "TBwords_nr";
            this.TBwords_nr.ReadOnly = true;
            this.TBwords_nr.Size = new System.Drawing.Size(92, 24);
            this.TBwords_nr.TabIndex = 5;
            // 
            // TBcurrent_word_nr
            // 
            this.TBcurrent_word_nr.Location = new System.Drawing.Point(142, 26);
            this.TBcurrent_word_nr.MaxLength = 10;
            this.TBcurrent_word_nr.Name = "TBcurrent_word_nr";
            this.TBcurrent_word_nr.Size = new System.Drawing.Size(92, 24);
            this.TBcurrent_word_nr.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 17);
            this.label13.TabIndex = 3;
            this.label13.Text = "Nr bieżącego słówka:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Pozostały czas nauki:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Liczba słówek:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.TBlast_wordbase_name);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Location = new System.Drawing.Point(631, 529);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(550, 61);
            this.groupBox7.TabIndex = 18;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Historia";
            // 
            // TBlast_wordbase_name
            // 
            this.TBlast_wordbase_name.Location = new System.Drawing.Point(142, 26);
            this.TBlast_wordbase_name.Name = "TBlast_wordbase_name";
            this.TBlast_wordbase_name.ReadOnly = true;
            this.TBlast_wordbase_name.Size = new System.Drawing.Size(398, 24);
            this.TBlast_wordbase_name.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 17);
            this.label14.TabIndex = 9;
            this.label14.Text = "Nazwa ostatniej bazy:";
            // 
            // Bstart_learning
            // 
            this.Bstart_learning.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Bstart_learning.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Bstart_learning.Location = new System.Drawing.Point(631, 596);
            this.Bstart_learning.Name = "Bstart_learning";
            this.Bstart_learning.Size = new System.Drawing.Size(270, 74);
            this.Bstart_learning.TabIndex = 19;
            this.Bstart_learning.Text = "Rozpocznij naukę (Space)";
            this.Bstart_learning.UseVisualStyleBackColor = true;
            this.Bstart_learning.Click += new System.EventHandler(this.Bstart_learning_Click);
            // 
            // Brestore_default
            // 
            this.Brestore_default.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Brestore_default.Font = new System.Drawing.Font("Calibri", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Brestore_default.Location = new System.Drawing.Point(911, 596);
            this.Brestore_default.Name = "Brestore_default";
            this.Brestore_default.Size = new System.Drawing.Size(270, 74);
            this.Brestore_default.TabIndex = 20;
            this.Brestore_default.Text = "Przywróc ustawienia domyślne";
            this.Brestore_default.UseVisualStyleBackColor = true;
            this.Brestore_default.Click += new System.EventHandler(this.Brestore_default_Click);
            // 
            // OFD1
            // 
            this.OFD1.FileName = "openFileDialog1";
            // 
            // Badd_word
            // 
            this.Badd_word.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Badd_word.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Badd_word.Location = new System.Drawing.Point(334, 629);
            this.Badd_word.Name = "Badd_word";
            this.Badd_word.Size = new System.Drawing.Size(290, 41);
            this.Badd_word.TabIndex = 8;
            this.Badd_word.Text = "Dodaj słówko";
            this.Badd_word.UseVisualStyleBackColor = true;
            this.Badd_word.Click += new System.EventHandler(this.Badd_word_Click);
            // 
            // Badd_wordbase
            // 
            this.Badd_wordbase.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Badd_wordbase.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Badd_wordbase.Location = new System.Drawing.Point(36, 629);
            this.Badd_wordbase.Name = "Badd_wordbase";
            this.Badd_wordbase.Size = new System.Drawing.Size(290, 41);
            this.Badd_wordbase.TabIndex = 21;
            this.Badd_wordbase.Text = "Dodaj bazę słówek";
            this.Badd_wordbase.UseVisualStyleBackColor = true;
            this.Badd_wordbase.Click += new System.EventHandler(this.Badd_wordbase_Click_1);
            // 
            // PB_move_up
            // 
            this.PB_move_up.Image = ((System.Drawing.Image)(resources.GetObject("PB_move_up.Image")));
            this.PB_move_up.Location = new System.Drawing.Point(2, 303);
            this.PB_move_up.Name = "PB_move_up";
            this.PB_move_up.Size = new System.Drawing.Size(32, 32);
            this.PB_move_up.TabIndex = 22;
            this.PB_move_up.TabStop = false;
            this.PB_move_up.Click += new System.EventHandler(this.PB_move_up_Click);
            // 
            // PB_move_down
            // 
            this.PB_move_down.Image = ((System.Drawing.Image)(resources.GetObject("PB_move_down.Image")));
            this.PB_move_down.Location = new System.Drawing.Point(2, 340);
            this.PB_move_down.Name = "PB_move_down";
            this.PB_move_down.Size = new System.Drawing.Size(32, 32);
            this.PB_move_down.TabIndex = 23;
            this.PB_move_down.TabStop = false;
            this.PB_move_down.Click += new System.EventHandler(this.PB_move_down_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.CBvoice_f);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.CBvolume);
            this.groupBox8.Controls.Add(this.CBvoice_n);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Location = new System.Drawing.Point(939, 60);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(244, 107);
            this.groupBox8.TabIndex = 24;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Syntezator mowy";
            // 
            // CBvoice_f
            // 
            this.CBvoice_f.FormattingEnabled = true;
            this.CBvoice_f.Location = new System.Drawing.Point(82, 49);
            this.CBvoice_f.Name = "CBvoice_f";
            this.CBvoice_f.Size = new System.Drawing.Size(156, 23);
            this.CBvoice_f.TabIndex = 5;
            this.CBvoice_f.SelectedIndexChanged += new System.EventHandler(this.CBvoice_f_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Głos j. obcy";
            // 
            // CBvolume
            // 
            this.CBvolume.FormattingEnabled = true;
            this.CBvolume.Location = new System.Drawing.Point(82, 76);
            this.CBvolume.Name = "CBvolume";
            this.CBvolume.Size = new System.Drawing.Size(156, 23);
            this.CBvolume.TabIndex = 3;
            this.CBvolume.SelectedIndexChanged += new System.EventHandler(this.CBvolume_SelectedIndexChanged);
            // 
            // CBvoice_n
            // 
            this.CBvoice_n.FormattingEnabled = true;
            this.CBvoice_n.Location = new System.Drawing.Point(82, 22);
            this.CBvoice_n.Name = "CBvoice_n";
            this.CBvoice_n.Size = new System.Drawing.Size(156, 23);
            this.CBvoice_n.TabIndex = 2;
            this.CBvoice_n.SelectedIndexChanged += new System.EventHandler(this.CBvoice_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 79);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 17);
            this.label16.TabIndex = 1;
            this.label16.Text = "Głośność";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(76, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "Głos j. polski";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.RBvariable_color);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.RBconstant_color);
            this.groupBox9.Controls.Add(this.TBback_color);
            this.groupBox9.Location = new System.Drawing.Point(1008, 415);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(175, 108);
            this.groupBox9.TabIndex = 25;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Kolor tła podczas nauki";
            // 
            // RBvariable_color
            // 
            this.RBvariable_color.AutoSize = true;
            this.RBvariable_color.Location = new System.Drawing.Point(6, 79);
            this.RBvariable_color.Name = "RBvariable_color";
            this.RBvariable_color.Size = new System.Drawing.Size(123, 21);
            this.RBvariable_color.TabIndex = 4;
            this.RBvariable_color.TabStop = true;
            this.RBvariable_color.Text = "Zmienny kolor tła";
            this.RBvariable_color.UseVisualStyleBackColor = true;
            this.RBvariable_color.CheckedChanged += new System.EventHandler(this.RBvariable_color_CheckedChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 51);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 17);
            this.label18.TabIndex = 3;
            this.label18.Text = "Kolor:";
            // 
            // RBconstant_color
            // 
            this.RBconstant_color.AutoSize = true;
            this.RBconstant_color.Location = new System.Drawing.Point(6, 23);
            this.RBconstant_color.Name = "RBconstant_color";
            this.RBconstant_color.Size = new System.Drawing.Size(102, 21);
            this.RBconstant_color.TabIndex = 2;
            this.RBconstant_color.TabStop = true;
            this.RBconstant_color.Text = "Stały kolor tła";
            this.RBconstant_color.UseVisualStyleBackColor = true;
            this.RBconstant_color.CheckedChanged += new System.EventHandler(this.RBconstant_color_CheckedChanged);
            // 
            // TBback_color
            // 
            this.TBback_color.BackColor = System.Drawing.Color.White;
            this.TBback_color.Location = new System.Drawing.Point(45, 48);
            this.TBback_color.Name = "TBback_color";
            this.TBback_color.ReadOnly = true;
            this.TBback_color.Size = new System.Drawing.Size(118, 24);
            this.TBback_color.TabIndex = 1;
            this.TBback_color.Click += new System.EventHandler(this.TBback_color_Click);
            this.TBback_color.TextChanged += new System.EventHandler(this.TBback_color_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(530, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 26;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 674);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.PB_move_down);
            this.Controls.Add(this.PB_move_up);
            this.Controls.Add(this.Badd_wordbase);
            this.Controls.Add(this.Brestore_default);
            this.Controls.Add(this.Bstart_learning);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Badd_word);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LBwords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.LBwordbases);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1203, 713);
            this.MinimumSize = new System.Drawing.Size(1203, 713);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Automatyczna nauka języków";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.CMS_LBwordbases.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.CMS_LBwords.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_move_up)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_move_down)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.ListBox LBwordbases;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TSMIplik;
        private System.Windows.Forms.ToolStripMenuItem TSMIload_wordbases;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ListBox LBwords;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CHBshow_words;
        private System.Windows.Forms.RadioButton RBn_f;
        private System.Windows.Forms.RadioButton RBf_n;
        private System.Windows.Forms.CheckBox CHBread_sentence_f;
        private System.Windows.Forms.CheckBox CHBread_sentence_n;
        private System.Windows.Forms.CheckBox CHBread_word_f;
        private System.Windows.Forms.CheckBox CHBread_word_n;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox CHBshow_sentences;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBbetween_delay;
        private System.Windows.Forms.TextBox TBsentence_delay;
        private System.Windows.Forms.TextBox TBword_delay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TBrepeats;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton RBchecking;
        private System.Windows.Forms.RadioButton RBpresentation;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox TBremaining_time;
        public System.Windows.Forms.TextBox TBwords_nr;
        public System.Windows.Forms.TextBox TBcurrent_word_nr;
        private System.Windows.Forms.Button Breset_current_word_nr;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.TextBox TBlast_wordbase_name;
        private System.Windows.Forms.Button Bstart_learning;
        private System.Windows.Forms.Button Brestore_default;
        private System.Windows.Forms.ToolStripMenuItem TSMIcontrol_keys;
        private System.Windows.Forms.OpenFileDialog OFD1;
        private System.Windows.Forms.RadioButton RBhybrid;
        private System.Windows.Forms.ToolStripMenuItem TSMIhelp;
        private System.Windows.Forms.Button Badd_word;
        private System.Windows.Forms.Button Badd_wordbase;
        private System.Windows.Forms.PictureBox PB_move_up;
        private System.Windows.Forms.PictureBox PB_move_down;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox CBvoice_n;
        private System.Windows.Forms.ComboBox CBvolume;
        private System.Windows.Forms.ComboBox CBvoice_f;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ContextMenuStrip CMS_LBwords;
        private System.Windows.Forms.ToolStripMenuItem TSMIset_word_as_current;
        private System.Windows.Forms.ToolStripMenuItem TSMIedit_word;
        private System.Windows.Forms.ToolStripMenuItem TSMIdelete_word;
        private System.Windows.Forms.ContextMenuStrip CMS_LBwordbases;
        private System.Windows.Forms.ToolStripMenuItem TSMIedit_wordbase;
        private System.Windows.Forms.ToolStripMenuItem TSMIdelete_wordbase;
        private System.Windows.Forms.RadioButton RBsemi_auto;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TextBox TBback_color;
        private System.Windows.Forms.RadioButton RBconstant_color;
        private System.Windows.Forms.RadioButton RBvariable_color;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton RBturbo;
    }
}

