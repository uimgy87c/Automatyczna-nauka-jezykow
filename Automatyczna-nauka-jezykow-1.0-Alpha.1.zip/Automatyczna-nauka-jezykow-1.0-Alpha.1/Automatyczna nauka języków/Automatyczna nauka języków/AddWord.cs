﻿using System.Windows.Forms;

namespace Automatyczna_nauka_języków
{
    public partial class AddWord : Form
    {
        public AddWord()
        {
            InitializeComponent();
        }
    }
}
